import time
from pathlib import Path
from collections import Counter

import cv2
import numpy as np
import pandas as pd
import streamlit as st

from config import APP_NAME, MODEL_NAME, DEFAULT_CONFIDENCE, DEFAULT_HORIZON_SECONDS, MAX_HISTORY, OUTPUT_DIR
from modules.detection import Detector
from modules.tracking import CentroidTracker
from modules.prediction import predict_track
from modules.reconstruction import make_scene_figure
from modules.spatial_reasoning import relationships
from modules.depth_estimation import relative_depth_preview
from modules.scene_analysis import analyze_scene
from utils.data_export import detections_to_csv

st.set_page_config(page_title=APP_NAME, page_icon="🌐", layout="wide", initial_sidebar_state="collapsed")
BASE = Path(__file__).resolve().parent
css_file = BASE / "assets" / "styles.css"
if css_file.exists():
    st.markdown(f"<style>{css_file.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)

st.markdown("""
<div class="nx-header">
  <div class="brand"><div class="orb">🌐</div><div>
    <div class="nx-title">NEXWORLD <span>4D</span></div>
    <div class="subtitle">AI-Powered 3D Scene Reconstruction, Spatial Reasoning and Dynamic World Evolution</div>
  </div></div>
  <div class="workflow"><b>SEE</b> → <b>UNDERSTAND</b> → <b>RECONSTRUCT</b> → <b>PREDICT</b>
    <div class="tagline">From real world to a smart 4D digital world</div>
  </div>
</div>
""", unsafe_allow_html=True)

def init_state():
    defaults = {
        "detector": None, "tracker": CentroidTracker(), "history": [],
        "last_frame": None, "last_annotated": None, "last_detections": [],
        "last_predictions": {}, "frame_index": 0, "camera_frame": None,
        "status": "Ready", "source_mode": "Upload image / video"
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()

with st.sidebar:
    st.markdown("## ◈ CONTROL DECK")
    source_mode = st.radio("Input source", ["Upload image / video", "Webcam (snapshot mode)"])
    conf = st.slider("Detection confidence", 0.10, 0.90, float(DEFAULT_CONFIDENCE), 0.05)
    horizon = st.slider("Prediction horizon (seconds)", 1, 10, int(DEFAULT_HORIZON_SECONDS))
    show_boxes = st.toggle("Show detection boxes", True)
    show_trails = st.toggle("Show movement trails", True)
    show_3d = st.toggle("Enable scene view", True)
    run = st.button("▶ PROCESS INPUT", use_container_width=True)
    reset = st.button("↺ CLEAR TRACKING HISTORY", use_container_width=True)
    st.caption("CPU supported. First model use may download YOLO weights.")
    st.markdown("---")
    st.markdown("**MODULE STATUS**")
    for name, state in [
        ("Object Detection", "Loaded" if st.session_state.detector else "Standby"),
        ("Object Tracking", "Ready"),
        ("Depth Estimation", "Relative image proxy"),
        ("3D Reconstruction", "Illustrative image-plane"),
        ("Spatial Reasoning", "Pixel-space"),
        ("Future Prediction", "Constant velocity"),
    ]:
        st.markdown(f'<div class="module"><i></i><span>{name}</span><small>{state}</small></div>', unsafe_allow_html=True)

if reset:
    st.session_state.tracker = CentroidTracker()
    st.session_state.history = []
    st.session_state.last_detections = []
    st.session_state.last_predictions = {}
    st.session_state.last_frame = None
    st.session_state.last_annotated = None
    st.session_state.status = "Tracking history cleared"

uploaded = None
if source_mode == "Upload image / video":
    uploaded = st.file_uploader("Upload image or video", type=["jpg", "jpeg", "png", "bmp", "mp4", "avi", "mov", "mkv", "mpeg4"])
else:
    if st.button("📷 Capture webcam frame"):
        cap = cv2.VideoCapture(0)
        ok, image = cap.read() if cap.isOpened() else (False, None)
        cap.release()
        if ok:
            st.session_state.camera_frame = image
            st.session_state.status = "Webcam frame captured"
        else:
            st.error("Could not open webcam. Check Windows camera permissions and close other camera apps.")
    if st.session_state.camera_frame is not None:
        st.image(cv2.cvtColor(st.session_state.camera_frame, cv2.COLOR_BGR2RGB), caption="Captured webcam frame", use_container_width=True)

def load_detector():
    if st.session_state.detector is None:
        with st.spinner(f"Loading {MODEL_NAME}; first use may download weights..."):
            st.session_state.detector = Detector(MODEL_NAME)
    return st.session_state.detector

def process_frame(frame, confidence, seconds):
    detections = load_detector().detect(frame, confidence)
    now = time.time()
    tracked = st.session_state.tracker.update(detections, now)
    annotated = frame.copy()
    predictions = {}
    for d in tracked:
        tid = d.get("track_id")
        track = st.session_state.tracker.tracks.get(tid)
        if track:
            p = predict_track(track, seconds)
            if p.get("available"):
                predictions[tid] = p
    if show_boxes:
        for d in tracked:
            x1, y1, x2, y2 = map(int, d["xyxy"])
            color = (255, 210, 40)
            cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
            label = f'{d.get("class_name","object")} #{d.get("track_id","?")} {float(d.get("confidence",0)):.2f}'
            top = max(0, y1 - 24)
            right = min(annotated.shape[1] - 1, x1 + max(130, len(label) * 9))
            cv2.rectangle(annotated, (x1, top), (right, y1), color, -1)
            cv2.putText(annotated, label, (x1 + 4, max(16, y1 - 7)), cv2.FONT_HERSHEY_SIMPLEX, .48, (4, 14, 25), 1, cv2.LINE_AA)
    if show_trails:
        for track in st.session_state.tracker.tracks.values():
            hist = list(track["history"])
            if len(hist) > 1:
                pts = np.array([[int(p[1]), int(p[2])] for p in hist], np.int32).reshape((-1, 1, 2))
                cv2.polylines(annotated, [pts], False, (80, 245, 150), 2)
    for p in predictions.values():
        xy = [(int(p["current"]["x"]), int(p["current"]["y"]))]
        xy.extend((int(q["x"]), int(q["y"])) for q in p.get("points", []))
        for a, b in zip(xy, xy[1:]):
            cv2.line(annotated, a, b, (80, 245, 150), 2, cv2.LINE_AA)
        if xy:
            cv2.circle(annotated, xy[-1], 6, (80, 245, 150), -1)
    st.session_state.last_frame = frame.copy()
    st.session_state.last_annotated = annotated
    st.session_state.last_detections = tracked
    st.session_state.last_predictions = predictions
    st.session_state.history.append({"time": now, "frame": frame.copy(), "annotated": annotated.copy(), "detections": tracked.copy(), "predictions": predictions.copy()})
    st.session_state.history = st.session_state.history[-MAX_HISTORY:]
    st.session_state.frame_index += 1
    st.session_state.status = "Processing complete"

if run:
    try:
        if source_mode == "Webcam (snapshot mode)":
            frame = st.session_state.camera_frame
            if frame is None:
                st.warning("Capture a webcam frame first.")
            else:
                process_frame(frame, conf, horizon)
                st.rerun()
        elif uploaded is None:
            st.warning("Upload an image or video first.")
        else:
            suffix = Path(uploaded.name).suffix.lower()
            raw = uploaded.getvalue()
            if suffix in {".jpg", ".jpeg", ".png", ".bmp"}:
                frame = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
                if frame is None:
                    st.error("Image could not be decoded.")
                else:
                    process_frame(frame, conf, horizon)
                    st.rerun()
            else:
                OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
                video_path = OUTPUT_DIR / ("uploaded_video" + suffix)
                video_path.write_bytes(raw)
                cap = cv2.VideoCapture(str(video_path))
                if not cap.isOpened():
                    st.error("Video could not be opened. Try MP4 (H.264) or AVI.")
                else:
                    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
                    stride = max(1, int(total / 90)) if total else 3
                    progress, status = st.progress(0), st.empty()
                    i = done = 0
                    while True:
                        ok, frame = cap.read()
                        if not ok:
                            break
                        if i % stride == 0:
                            process_frame(frame, conf, horizon)
                            done += 1
                            if total:
                                progress.progress(min(1.0, i / max(1, total)))
                            status.caption(f"Processed frame {i + 1}" + (f" / {total}" if total else ""))
                        i += 1
                    cap.release()
                    progress.empty()
                    status.empty()
                    st.success(f"Video processing finished: {done} sampled frames processed.")
                    st.rerun()
    except Exception as e:
        st.session_state.status = "Error"
        st.error(f"Processing failed: {e}")
        st.info("Check installed dependencies and ensure the YOLO model weights can be loaded.")

frame = st.session_state.last_frame
current = st.session_state.last_annotated
detections = st.session_state.last_detections
predictions = st.session_state.last_predictions
tracks = st.session_state.tracker.tracks
counts = Counter(str(d.get("class_name", "unknown")).lower().strip() for d in detections)
people = counts.get("person", 0)
vehicle_names = {"car", "truck", "bus", "motorcycle", "motorbike", "bicycle", "van", "scooter", "pickup", "pickup truck"}
vehicles = sum(n for name, n in counts.items() if name in vehicle_names)
moving = sum(1 for tr in tracks.values() if len(tr.get("history", [])) > 1 and ((tr["history"][-1][1]-tr["history"][-2][1])**2 + (tr["history"][-1][2]-tr["history"][-2][2])**2)**0.5 > 3)

metric_cols = st.columns(5)
for col, label, value in zip(metric_cols, ["OBJECTS", "PEOPLE", "VEHICLES", "MOVING TRACKS", "HISTORY FRAMES"], [len(detections), people, vehicles, moving, len(st.session_state.history)]):
    with col:
        st.markdown(f'<div class="metric"><small>{label}</small><strong>{value}</strong></div>', unsafe_allow_html=True)

cam_col, world_col, understanding_col = st.columns([1.08, 1.28, 1.08], gap="small")
with cam_col:
    st.markdown('<div class="panel-title">◉ LIVE CAMERA VIEW</div>', unsafe_allow_html=True)
    if current is not None:
        st.image(cv2.cvtColor(current, cv2.COLOR_BGR2RGB), use_container_width=True)
        st.markdown(f'<div class="small-note">● {st.session_state.status} &nbsp; · &nbsp; {len(detections)} detections</div>', unsafe_allow_html=True)
        st.download_button("⬇ Download annotated frame", cv2.imencode(".png", current)[1].tobytes(), "nexworld_scene.png", "image/png", use_container_width=True)
    else:
        st.markdown('<div class="empty">Awaiting image, video, or webcam input.</div>', unsafe_allow_html=True)
    st.markdown('<div class="panel-title">▦ DETECTED OBJECTS</div>', unsafe_allow_html=True)
    cards = [("PERSON", "person", "♟", "green"), ("CAR", "car", "▰", "red"), ("CHAIR", "chair", "▤", "blue"), ("DOOR", "door", "▯", "purple"), ("TREE", "tree", "♣", "green")]
    obj_cols = st.columns(3)
    for i, (label, key, icon, color) in enumerate(cards):
        with obj_cols[i % 3]:
            st.markdown(f'<div class="object-card {color}"><div>{icon}</div><small>{label}</small><b>{counts.get(key, 0)}</b></div>', unsafe_allow_html=True)
    with st.expander("All detected classes"):
        st.dataframe(pd.DataFrame([{"Class": k.title(), "Count": v} for k, v in counts.most_common()]), use_container_width=True, hide_index=True) if counts else st.caption("No detections yet.")

with world_col:
    st.markdown('<div class="panel-title">⬡ 3D WORLD RECONSTRUCTION</div>', unsafe_allow_html=True)
    if show_3d and frame is not None:
        try:
            fig = make_scene_figure(tracks, frame.shape, predictions, show_trails)
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        except Exception as e:
            st.warning(f"Scene view unavailable: {e}")
    else:
        st.markdown('<div class="empty scene-empty">Process an input to populate the scene visualization.</div>', unsafe_allow_html=True)
    rgb_col, depth_col = st.columns(2, gap="small")
    with rgb_col:
        st.markdown('<div class="mini-title">RGB INPUT</div>', unsafe_allow_html=True)
        if frame is not None:
            st.image(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), use_container_width=True)
        else:
            st.caption("Waiting for input")
    with depth_col:
        st.markdown('<div class="mini-title">DEPTH PROXY</div>', unsafe_allow_html=True)
        if frame is not None:
            st.image(cv2.cvtColor(relative_depth_preview(frame), cv2.COLOR_BGR2RGB), use_container_width=True)
        else:
            st.caption("Waiting for input")
    st.markdown('<div class="pills"><span>✓ Detection</span><span>✓ Tracking</span><span>◌ Depth proxy</span></div>', unsafe_allow_html=True)
    st.caption("The scene/depth panels are illustrative image-space proxies, not calibrated metric 3D.")

with understanding_col:
    st.markdown('<div class="panel-title">◈ WORLD UNDERSTANDING</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="understand-row"><span>⬡ Objects</span><b>{len(detections)}</b></div><div class="understand-row"><span>♟ People</span><b>{people}</b></div><div class="understand-row"><span>▰ Vehicles</span><b>{vehicles}</b></div><div class="understand-row"><span>⌁ Moving objects</span><b>{moving}</b></div><div class="understand-row"><span>▣ Other detections</span><b>{max(0,len(detections)-people-vehicles)}</b></div>', unsafe_allow_html=True)
    st.markdown('<div class="panel-title">⌖ SPATIAL RELATIONSHIPS</div>', unsafe_allow_html=True)
    rel = []
    if frame is not None and tracks:
        try:
            rel = relationships(tracks, frame.shape[1], frame.shape[0])
        except Exception:
            rel = []
    if rel:
        for row in rel[:5]:
            vals = list(row.values())
            st.markdown(f'<div class="relation"><span>{vals[0]}</span><b>{" · ".join(str(x) for x in vals[1:])}</b></div>', unsafe_allow_html=True)
    else:
        st.caption("Proximity appears when multiple objects are tracked.")
    st.markdown('<div class="panel-title">✓ SCENE ANALYSIS</div>', unsafe_allow_html=True)
    if frame is not None:
        try:
            analysis = analyze_scene(frame, tracks)
            st.markdown(f'<div class="analysis">✓ Quality: {analysis.get("quality","evaluated")}<br>✓ Brightness: {analysis.get("brightness","—")}<br>✓ People: {analysis.get("people",people)} · Vehicles: {analysis.get("vehicles",vehicles)}<br>✓ Moving tracks: {analysis.get("moving",moving)}</div>', unsafe_allow_html=True)
            st.caption(analysis.get("note", "Image-based analysis only."))
        except Exception as e:
            st.caption(f"Scene analysis unavailable: {e}")
    else:
        st.caption("Scene analysis appears after processing input.")

timeline_col, prediction_col, insights_col = st.columns([1.4, 1.12, .9], gap="small")
with timeline_col:
    st.markdown('<div class="panel-title">◷ WORLD EVOLUTION · PAST → NOW → FUTURE</div>', unsafe_allow_html=True)
    history = st.session_state.history
    if len(history) > 1:
        ix = st.slider("Inspect recorded observation", 0, len(history)-1, len(history)-1, key="history_frame_slider")
        snap = history[ix]
    elif len(history) == 1:
        ix, snap = 0, history[0]
        st.caption("One observation recorded. Process a video or capture more snapshots to compare frames.")
    else:
        ix, snap = -1, None
    if snap is not None:
        a, b = st.columns(2, gap="small")
        with a:
            st.markdown('<div class="mini-title">RECORDED FRAME</div>', unsafe_allow_html=True)
            st.image(cv2.cvtColor(snap["frame"], cv2.COLOR_BGR2RGB), use_container_width=True)
        with b:
            st.markdown('<div class="mini-title">DETECTION OVERLAY</div>', unsafe_allow_html=True)
            st.image(cv2.cvtColor(snap["annotated"], cv2.COLOR_BGR2RGB), use_container_width=True)
        st.caption(f"Observation {ix+1} of {len(history)}. Future positions are estimates, not future camera images.")
    else:
        st.markdown('<div class="empty">Timeline will appear after the first processed frame.</div>', unsafe_allow_html=True)

with prediction_col:
    st.markdown('<div class="panel-title">◉ FUTURE PREDICTION</div>', unsafe_allow_html=True)
    available = [(tid, p) for tid, p in predictions.items() if p.get("available")]
    if available:
        tid, p = available[0]
        tr = tracks.get(tid, {})
        st.markdown(f'<div class="prediction"><small>PREDICTED TRACK</small><b>{str(tr.get("class_name","object")).title()} #{tid}</b><span>HORIZON +{horizon}s</span></div>', unsafe_allow_html=True)
        st.write(f"Estimated image-space speed: **{p.get('speed_px_s',0):.1f} px/s**")
        future = p.get("future", {})
        st.write(f"Projected point: **x={future.get('x',0):.0f}, y={future.get('y',0):.0f}**")
        stability = p.get("stability_indicator")
        if stability is not None:
            st.progress(max(0.0, min(1.0, float(stability))))
            st.caption(f"Motion stability heuristic: {float(stability):.0%}")
        st.caption(p.get("note", "Constant-velocity estimate."))
    else:
        st.markdown('<div class="empty">Prediction needs repeated observations of the same track.</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="horizon">PREDICTION HORIZON: {horizon} SECONDS</div>', unsafe_allow_html=True)
    st.caption("Image-space extrapolation does not identify intent or guarantee future motion.")

with insights_col:
    st.markdown('<div class="panel-title">✧ AI INSIGHTS</div>', unsafe_allow_html=True)
    if detections:
        st.markdown(f'<div class="insight">Observed <b>{len(detections)}</b> detections across <b>{len(counts)}</b> classes.</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="insight">Recent movement heuristic: <b>{moving}</b> track(s) changed image position.</div>', unsafe_allow_html=True)
        if available:
            tid, p = available[0]
            st.markdown(f'<div class="insight">Track <b>#{tid}</b> has a constant-velocity projection for the next {horizon}s.</div>', unsafe_allow_html=True)
    else:
        st.markdown('<div class="empty">Insights appear after actual detections.</div>', unsafe_allow_html=True)
    st.markdown('<div class="safety">Computer-vision observations and simple motion estimates only; not a safety assessment.</div>', unsafe_allow_html=True)

with st.expander("RGB · DEPTH PROXY · SCENE MAP", expanded=False):
    if frame is not None:
        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown("**RGB INPUT**")
            st.image(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), use_container_width=True)
        with c2:
            st.markdown("**RELATIVE DEPTH PROXY**")
            st.image(cv2.cvtColor(relative_depth_preview(frame), cv2.COLOR_BGR2RGB), use_container_width=True)
        with c3:
            st.markdown("**SCENE MAP**")
            if show_3d:
                try:
                    st.plotly_chart(make_scene_figure(tracks, frame.shape, predictions, show_trails), use_container_width=True, config={"displayModeBar": False})
                except Exception as e:
                    st.caption(f"Scene map unavailable: {e}")
            else:
                st.caption("Scene view disabled.")
    else:
        st.caption("Process an input to populate previews.")

st.markdown("---")
save_col, export_col, note_col = st.columns([1, 1, 2])
with save_col:
    if st.button("📸 Save scene snapshot", use_container_width=True):
        if current is not None:
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            path = OUTPUT_DIR / "nexworld_snapshot.png"
            cv2.imwrite(str(path), current)
            st.success(f"Saved to {path}")
        else:
            st.warning("Process an input first.")
with export_col:
    st.download_button("⬇ Export detections CSV", detections_to_csv(detections), "nexworld_detections.csv", "text/csv", use_container_width=True)
with note_col:
    st.caption("NEXWORLD 4D · Actual object classes depend on the detector. True metric depth, real-world distances and geometric 3D reconstruction require calibration/depth data.")
st.markdown('<div class="footer"><span></span><b>REAL WORLD&nbsp; + &nbsp; AI&nbsp; = &nbsp; SMARTER TOMORROW</b><span></span></div>', unsafe_allow_html=True)
